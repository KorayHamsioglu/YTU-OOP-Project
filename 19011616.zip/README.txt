COMPILING

Go to the project file and type cmd in directory line.
After command prompt opens compile all .java files via typing javac
For this project --->javac src/project/*.java (* is for multiple classes inside of the project)
After compiling the project in package file there will be a .class file for every .java file
After .class (runnable) files created we can run the program via typing java command in command prompt
------------------------------------------------------------------------------
RUNNING

Go to src file and type cmd into directory line.
Type java packagename.mainclassname to run our program via command prompt
For this project---> java project.InformationSystem
------------------------------------------------------------------------------